package com.example.linkedin.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.linkedin.demo.model.LinkedInConnection;
import com.example.linkedin.demo.repo.LinkedInConnectionRepository;

@Service
public class LinkedInConnectionService {
@Autowired
LinkedInConnectionRepository lirep;

public List<LinkedInConnection> getAllLinkedInConnection()
{
	List<LinkedInConnection> liList=lirep.findAll();
	return liList;
}
public LinkedInConnection saveConnection(LinkedInConnection c)
{
	return lirep.save(c);
}


public void deleteConnection(String username) 
{
	lirep.deleteById(username);
	
}
}