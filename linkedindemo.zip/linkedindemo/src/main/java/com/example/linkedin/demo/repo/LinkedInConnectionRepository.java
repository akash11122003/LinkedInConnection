package com.example.linkedin.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.linkedin.demo.model.LinkedInConnection;
public interface LinkedInConnectionRepository extends JpaRepository<LinkedInConnection, String>{

}
