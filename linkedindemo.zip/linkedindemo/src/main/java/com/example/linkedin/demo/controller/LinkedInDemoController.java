package com.example.linkedin.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.linkedin.demo.model.LinkedInConnection;
import com.example.linkedin.demo.service.LinkedInConnectionService;

@RestController
public class LinkedInDemoController {
@Autowired
	LinkedInConnectionService liSer;
	
	@GetMapping(value="/fetchConn")
	public List<LinkedInConnection> getAllLinkedInConnection()
	{
		
	List<LinkedInConnection> liList=liSer.getAllLinkedInConnection();
	return liList;
}
	@PostMapping(value="/insertConn")
	public LinkedInConnection saveConnection(@RequestBody LinkedInConnection c) {
		
		return liSer.saveConnection(c);
	}
	@PutMapping(value="/updateConn")
	
	public LinkedInConnection updateConnection(@RequestBody LinkedInConnection c)
	{
		return liSer.saveConnection(c);
	}
	
	
	@DeleteMapping(value="/deleteConn/{uname}")
	public String  deleteconnection(@PathVariable("uname") String username)
	{
		liSer.deleteConnection(username);
		return "Deleted";
	}
	
	
	
	
	
	
	
	
	
	
	
//	@GetMapping(value="/getStudent/{rno}")
//	public Student getStudent(@PathVariable("rno")  int regno)
//	{
//		return studService.getStudent(regno);
//	}
	
}