package com.example.linkedin.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinkedindemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinkedindemoApplication.class, args);
	}

}