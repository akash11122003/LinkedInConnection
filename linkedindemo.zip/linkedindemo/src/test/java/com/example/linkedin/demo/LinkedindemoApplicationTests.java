package com.example.linkedin.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedindemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
